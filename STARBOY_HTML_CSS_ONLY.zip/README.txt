
STARBOY — نسخه پیشرفته HTML/CSS (بدون JS)
-----------------------------------------
محتویات:
- index.html
- style.css
- assets/starboy-logo.svg

لینک‌ها:
- چت تلگرام: https://t.me/Yeat23
- کانال تلگرام: https://t.me/sinattyou

نحوه استفاده:
1) همه فایل‌ها را در یک پوشه قرار دهید.
2) index.html را با مرورگر باز کنید.
3) برای استقرار آنلاین، در هاست خود آپلود یا از Netlify/GitHub Pages استفاده کنید.
